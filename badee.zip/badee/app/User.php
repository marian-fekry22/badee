<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Laravel\Passport\HasApiTokens;
class User extends \TCG\Voyager\Models\User
{
    use Notifiable;
    use HasApiTokens, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','role_id' , 'token' , 'token_created_at'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function scopeDoctorUser($query)
    {
        return $query->where('role_id', 3);
    }

    public function createUser($data=array()){
        $tokenCreatedAt = Carbon::now();
        $tokenCreatedAt->toDateTimeString();
        $user=User::create([
            'name'=>$data['name'],
            'email'=>$data['email'],
            'role_id'=>4,
            'password'=>bcrypt($data['password']),
            'token'=>Str::random(32),
            'token_created_at'=>$tokenCreatedAt,
        ]);
        // add user role in the user_roles tabl
        return $user;
    }
}
