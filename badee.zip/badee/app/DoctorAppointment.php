<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DoctorAppointment  extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    //medical_provider relation
    public function doctor(){
        return $this->belongsTo('App\User' , 'user_id');
    }

}
