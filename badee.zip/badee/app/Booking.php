<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Booking  extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    //medical_provider relation
    protected $table= 'booking';
    public function doctor(){
        return $this->belongsTo('App\User' , 'doctor_id');
    }
    public function patient(){
        return $this->belongsTo('App\User' , 'patient_id');
    }

}
