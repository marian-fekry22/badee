<?php

namespace App\Http\Controllers;
use App\Request as RequestModel;
use Illuminate\Http\Request;
use Validator;
use Auth;


class BookingController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }
    public function bookAppointment(Request $request){

        $user=Auth::user();
        if($user->role_id!=4){
            return OutPut::Response('','you haven\'t permission',403);
        }
        app()->setLocale($user->token()->user_lang);
        $valid=Validator::make($request->all(),[
            'doctor_id'=>'required|Filled|numeric',
            'date'=>'required|Filled|date',
            'time_from'=>'required|Filled',
            'time_to'=>'required|Filled',
        ]);

        if($valid->fails()){
            return OutPut::Response('',$valid->Errors(),403);
        }

      $bookingModel = new \App\Booking();
        $bookingModel->doctor_id= $request->doctor_id;
        $bookingModel->patient_id= $user->id;
        $bookingModel->booking_date= $request->date;
        $bookingModel->time_from= $request->time_from;
        $bookingModel->time_to= $request->time_to;
        if($bookingModel->save()){
            return OutPut::Response('','booking successfuly',200);
        }
        else{
            return OutPut::Response('','plz try later',403);
        }

    }

    public function getAvailableAppointments (Request $request){
        $user=Auth::user();
        if($user->role_id!=4){
            return OutPut::Response('','you haven\'t permission',403);
        }
        app()->setLocale($user->token()->user_lang);
        $valid=Validator::make($request->all(),[
            'doctor_id'=>'required|Filled|numeric',
            'date'=>'required|Filled|date',
        ]);
        if($valid->fails()){
            return OutPut::Response('',$valid->Errors(),403);
        }
        $day = \Carbon\Carbon::createFromFormat('Y-m-d', $request->date)->format('l');
       $doctorAppointments = \App\DoctorAppointment::where('user_id' , $request->doctor_id)->where('day' , $day)->get();
       $appointments=[];
       foreach($doctorAppointments as $appointment){
           $fetchCat = new \App\DoctorAppointment();
           $fetchCat->id = $appointment->id;
           $fetchCat->time_from =  $appointment->time_from;
           $fetchCat->time_to =  $appointment->time_to;
           $dateFrom = $request->date." ".$appointment->time_from;
           $dateFrom = \Carbon\Carbon::parse($dateFrom);
           $dateTo = $request->date." ".$appointment->time_to;
           $dateTo = \Carbon\Carbon::parse($dateTo);
           $diff = \Carbon\Carbon::parse($dateFrom)->diffInHours($dateTo);
           for($i=0 ; $i <= $diff ;  $i++){
               $newTime =  $request->date." ".$appointment->time_from ;
               $newTime = \Carbon\Carbon::parse($newTime);
               $newTime = $newTime->addHour($i)->format('Y-m-d H:i:s');
               $timeArray =  explode(' ' , $newTime);
               $time = $timeArray[1];
               $booked = \App\Booking::where('doctor_id' , $request->doctor_id)->where('booking_date' , $request->date)->where('time_from' ,$time )->first();
               if(!$booked){
                   $appointments[] = $newTime;
               }
           }
       }

        return OutPut::Response($appointments,'',200);
    }

}
