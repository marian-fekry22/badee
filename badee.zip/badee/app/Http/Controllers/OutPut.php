<?php
namespace App\Http\Controllers;

trait OutPut{
  public static function Response($data=null,$message='',$status=200){
		$data=json_encode($data);
$cleanData=str_replace("null",'""',$data);
		$Output=array(
			'data'=>json_decode($cleanData,TRUE),
			'message'=>$message,
      'status'=>$status
		);
		if($message=='Unauthenticated'){
			$status=400;
		}
		return response($Output,$status);
	}

}


?>
